
import { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useSignInWithEmailAndPassword } from 'react-firebase-hooks/auth';
import { auth, db } from '../lib/firebase';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import styles from '../styles/Login.module.css';
import { FaEnvelope, FaLock, FaGoogle } from 'react-icons/fa';

export default function Home() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [signInWithEmailAndPassword, user, loading, error] = useSignInWithEmailAndPassword(auth);
  const router = useRouter();
  const [googleLoading, setGoogleLoading] = useState(false);

  useEffect(() => {
    if (user) {
      router.push('/dashboard');
    }
  }, [user, router]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    signInWithEmailAndPassword(email, password);
  };

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      // Check if user exists in our Firestore database
      const userDocRef = doc(db, 'users', user.uid);
      const userDoc = await getDoc(userDocRef);

      if (!userDoc.exists()) {
        // New user, create a document in Firestore
        await setDoc(userDocRef, {
          uid: user.uid,
          nama: user.displayName,
          email: user.email,
          role: 'warga',
          status: 'menunggu verifikasi',
          createdAt: new Date().toISOString(),
        });
        // Redirect to verification pending page
        router.push('/menunggu-verifikasi');
      }
      // If user exists, the useEffect hook will redirect them to the dashboard
      
    } catch (error) {
      console.error("Error during Google sign-in:", error);
    } finally {
      setGoogleLoading(false);
    }
  };


  return (
    <div className={styles.pageContainer}>
      <Head>
        <title>Login - WargaKoba</title>
      </Head>

      <div className={styles.visualSide}>
        <h1>Selamat Datang di WargaKoba</h1>
        <p>Solusi digital terintegrasi untuk manajemen data warga yang efisien, modern, dan aman.</p>
      </div>

      <div className={styles.formSide}>
        <div className={styles.formWrapper}>
          <div className={styles.header}>
            <h2>Masuk ke Akun Anda</h2>
            <p>Silakan masukkan kredensial Anda untuk melanjutkan.</p>
          </div>
          <form className={styles.form} onSubmit={handleLogin}>
            
            <div className={styles.inputGroup}>
              <FaEnvelope className={styles.inputIcon} />
              <input
                id="email"
                className={styles.input}
                type="email"
                placeholder="Email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className={styles.inputGroup}>
              <FaLock className={styles.inputIcon} />
              <input
                id="password"
                className={styles.input}
                type="password"
                placeholder="Kata Sandi"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            
            {error && <p className={styles.error}>{`Error: ${error.code.replace('auth/', '').replace(/-/g, ' ')}`}</p>}
            
            <button className={styles.button} type="submit" disabled={loading || googleLoading}>
              {loading ? 'Memproses...' : 'Login'}
            </button>
          </form>

          <div className={styles.separator}>
            <span>atau</span>
          </div>

          <button className={`${styles.button} ${styles.googleButton}`} onClick={handleGoogleSignIn} disabled={loading || googleLoading}>
            <FaGoogle className={styles.googleIcon} />
            {googleLoading ? 'Memproses...' : 'Masuk dengan Google'}
          </button>

          <div className={styles.footer}>
            <p>Belum punya akun? <Link href="/register">Daftar di sini</Link></p>
          </div>
        </div>
      </div>
    </div>
  );
}
